package com.biblioteca.servicio;

import com.biblioteca.dao.LibroDAO;
import com.biblioteca.dao.PrestamoDAO;
import com.biblioteca.modelo.Prestamo;
import javax.swing.*;
import java.sql.Date;
import java.time.LocalDate;

public class PrestamoService implements Runnable {
    private int idLibro;
    private int idEstudiante;
    private Runnable onComplete;

    public PrestamoService(int idLibro, int idEstudiante, Runnable onComplete) {
        this.idLibro = idLibro;
        this.idEstudiante = idEstudiante;
        this.onComplete = onComplete;
    }

    @Override
    public void run() {
        boolean stockOk = new LibroDAO().actualizarStockPrestamo(idLibro);

        if (stockOk) {
            Date fechaPrestamo = Date.valueOf(LocalDate.now());
            Date fechaDevolucion = Date.valueOf(LocalDate.now().plusDays(7));

            Prestamo p = new Prestamo(0, idEstudiante, idLibro, fechaPrestamo, fechaDevolucion, false);
            int resultado = new PrestamoDAO().registrarPrestamoConValidacion(p);

            SwingUtilities.invokeLater(() -> {
                if (resultado == 1) {
                    JOptionPane.showMessageDialog(null, "¡Préstamo registrado exitosamente!\nFecha de vencimiento: " + fechaDevolucion);
                    if (onComplete != null) onComplete.run();
                } else {
                    JOptionPane.showMessageDialog(null, "Error al registrar el préstamo.");
                }
            });
        } else {
            SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(null, "No hay stock suficiente."));
        }
    }
}

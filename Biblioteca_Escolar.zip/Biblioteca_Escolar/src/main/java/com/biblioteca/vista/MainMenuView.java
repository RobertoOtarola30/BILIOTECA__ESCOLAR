package com.biblioteca.vista;

import com.biblioteca.dao.EstudianteDAO;
import com.biblioteca.dao.LibroDAO;
import com.biblioteca.dao.PrestamoDAO;
import com.biblioteca.modelo.Estudiante;
import com.biblioteca.modelo.Libro;
import com.biblioteca.servicio.PrestamoService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class MainMenuView extends JFrame {

    private String rol;
    private DefaultTableModel modeloLibros;
    private DefaultTableModel modeloEstudiantes;
    private Runnable cargarTablaLibros;
    private Runnable cargarTablaEstudiantes;

    public MainMenuView(String rol) {
        this.rol = rol;
        setTitle("Sistema de Biblioteca Escolar - Rol: " + rol.toUpperCase());
        setSize(980, 680);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();

        tabs.add("Préstamos y Devoluciones", crearPanelPrestamosDevoluciones());

        if (rol.equalsIgnoreCase("bibliotecario")) {
            tabs.add("Gestión de Libros", crearPanelLibros());
            tabs.add("Gestión de Estudiantes", crearPanelEstudiantes());
            tabs.add("Reportes", crearPanelReportes());
        }

        tabs.addChangeListener(e -> {
            if (cargarTablaLibros != null) cargarTablaLibros.run();
            if (cargarTablaEstudiantes != null) cargarTablaEstudiantes.run();
        });

        add(tabs);
    }

    private JPanel crearPanelPrestamosDevoluciones() {
        JPanel panel = new JPanel(new GridLayout(2, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel pCrear = new JPanel(new GridLayout(3, 2, 5, 5));
        pCrear.setBorder(BorderFactory.createTitledBorder("Registrar Préstamo (Plazo: 7 Días)"));
        JTextField txtLibroP = new JTextField();
        JTextField txtEstP = new JTextField();
        JButton btnPrestar = new JButton("Procesar Préstamo");

        pCrear.add(new JLabel(" ID del Libro:")); pCrear.add(txtLibroP);
        pCrear.add(new JLabel(" ID del Estudiante:")); pCrear.add(txtEstP);
        pCrear.add(new JLabel("")); pCrear.add(btnPrestar);

        btnPrestar.addActionListener(e -> {
            try {
                int idL = Integer.parseInt(txtLibroP.getText().trim());
                int idE = Integer.parseInt(txtEstP.getText().trim());
                Thread hilo = new Thread(new PrestamoService(idL, idE, () -> {
                    txtLibroP.setText("");
                    txtEstP.setText("");
                    if (cargarTablaLibros != null) cargarTablaLibros.run();
                }));
                hilo.start();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Ingrese IDs numéricos válidos.");
            }
        });

        JPanel pDev = new JPanel(new GridLayout(3, 2, 5, 5));
        pDev.setBorder(BorderFactory.createTitledBorder("Registrar Devolución (Control de Atrasos)"));
        JTextField txtIdPres = new JTextField();
        JTextField txtIdLibDev = new JTextField();
        JButton btnDevolver = new JButton("Confirmar Devolución");

        pDev.add(new JLabel(" ID del Préstamo (o Libro):")); pDev.add(txtIdPres);
        pDev.add(new JLabel(" ID del Libro:")); pDev.add(txtIdLibDev);
        pDev.add(new JLabel("")); pDev.add(btnDevolver);

        btnDevolver.addActionListener(e -> {
            try {
                int idPres = Integer.parseInt(txtIdPres.getText().trim());
                int idLib = Integer.parseInt(txtIdLibDev.getText().trim());
                String resultado = new PrestamoDAO().registrarDevolucionConControlAtraso(idPres, idLib);
                JOptionPane.showMessageDialog(this, "Devolución Procesada:\n" + resultado);
                txtIdPres.setText("");
                txtIdLibDev.setText("");
                if (cargarTablaLibros != null) cargarTablaLibros.run();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Ingrese IDs numéricos válidos.");
            }
        });

        panel.add(pCrear);
        panel.add(pDev);
        return panel;
    }

    private JPanel crearPanelLibros() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        modeloLibros = new DefaultTableModel(new String[]{"ID", "Título", "Autor", "ISBN", "Editorial", "Stock", "Cat."}, 0);
        JTable tablaLibros = new JTable(modeloLibros);

        JPanel pForm = new JPanel(new GridLayout(7, 2, 5, 5));
        pForm.setBorder(BorderFactory.createTitledBorder("Formulario de Libros"));

        JTextField txtId = new JTextField(); txtId.setEditable(false);
        JTextField txtTitulo = new JTextField();
        JTextField txtAutor = new JTextField();
        JTextField txtIsbn = new JTextField();
        JTextField txtEditorial = new JTextField();
        JTextField txtStock = new JTextField();
        JTextField txtCat = new JTextField();

        pForm.add(new JLabel(" ID (Auto):")); pForm.add(txtId);
        pForm.add(new JLabel(" Título:")); pForm.add(txtTitulo);
        pForm.add(new JLabel(" Autor:")); pForm.add(txtAutor);
        pForm.add(new JLabel(" ISBN:")); pForm.add(txtIsbn);
        pForm.add(new JLabel(" Editorial:")); pForm.add(txtEditorial);
        pForm.add(new JLabel(" Stock:")); pForm.add(txtStock);
        pForm.add(new JLabel(" ID Categoría:")); pForm.add(txtCat);

        JPanel pBotones = new JPanel(new FlowLayout());
        JButton btnRegistrar = new JButton("Registrar");
        JButton btnModificar = new JButton("Modificar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnLimpiar = new JButton("Limpiar");
        JButton btnActualizar = new JButton("Actualizar Tabla");

        pBotones.add(btnRegistrar); pBotones.add(btnModificar); pBotones.add(btnEliminar); pBotones.add(btnLimpiar); pBotones.add(btnActualizar);

        cargarTablaLibros = () -> {
            modeloLibros.setRowCount(0);
            for (Libro l : new LibroDAO().listar()) {
                modeloLibros.addRow(new Object[]{l.getId(), l.getTitulo(), l.getAutor(), l.getIsbn(), l.getEditorial(), l.getStock(), l.getIdCategoria()});
            }
        };
        cargarTablaLibros.run();

        Runnable limpiarCampos = () -> {
            txtId.setText(""); txtTitulo.setText(""); txtAutor.setText(""); txtIsbn.setText(""); txtEditorial.setText(""); txtStock.setText(""); txtCat.setText("");
            tablaLibros.clearSelection();
        };

        tablaLibros.getSelectionModel().addListSelectionListener(e -> {
            int fila = tablaLibros.getSelectedRow();
            if (fila >= 0) {
                txtId.setText(tablaLibros.getValueAt(fila, 0).toString());
                txtTitulo.setText(tablaLibros.getValueAt(fila, 1).toString());
                txtAutor.setText(tablaLibros.getValueAt(fila, 2).toString());
                txtIsbn.setText(tablaLibros.getValueAt(fila, 3).toString());
                txtEditorial.setText(tablaLibros.getValueAt(fila, 4).toString());
                txtStock.setText(tablaLibros.getValueAt(fila, 5).toString());
                txtCat.setText(tablaLibros.getValueAt(fila, 6).toString());
            }
        });

        btnRegistrar.addActionListener(e -> {
            try {
                Libro l = new Libro(0, txtTitulo.getText().trim(), txtAutor.getText().trim(), txtIsbn.getText().trim(), txtEditorial.getText().trim(), Integer.parseInt(txtStock.getText().trim()), Integer.parseInt(txtCat.getText().trim()));
                boolean res = new LibroDAO().insertar(l);
                JOptionPane.showMessageDialog(this, res ? "Libro registrado exitosamente." : "Error al registrar.");
                if (res) { cargarTablaLibros.run(); limpiarCampos.run(); }
            } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Verifique datos numéricos."); }
        });

        btnModificar.addActionListener(e -> {
            try {
                if (txtId.getText().isEmpty()) { JOptionPane.showMessageDialog(this, "Seleccione un libro."); return; }
                Libro l = new Libro(Integer.parseInt(txtId.getText().trim()), txtTitulo.getText().trim(), txtAutor.getText().trim(), txtIsbn.getText().trim(), txtEditorial.getText().trim(), Integer.parseInt(txtStock.getText().trim()), Integer.parseInt(txtCat.getText().trim()));
                boolean res = new LibroDAO().actualizar(l);
                JOptionPane.showMessageDialog(this, res ? "Libro modificado exitosamente." : "Error al modificar.");
                if (res) { cargarTablaLibros.run(); limpiarCampos.run(); }
            } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Error en datos numéricos."); }
        });

        btnEliminar.addActionListener(e -> {
            try {
                if (txtId.getText().isEmpty()) { JOptionPane.showMessageDialog(this, "Seleccione un libro."); return; }
                int id = Integer.parseInt(txtId.getText().trim());
                if (JOptionPane.showConfirmDialog(this, "¿Desea eliminar este libro?", "Confirmar", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                    boolean res = new LibroDAO().eliminar(id);
                    JOptionPane.showMessageDialog(this, res ? "Libro eliminado con éxito." : "Error al eliminar.");
                    if (res) { cargarTablaLibros.run(); limpiarCampos.run(); }
                }
            } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Seleccione un libro válido."); }
        });

        btnLimpiar.addActionListener(e -> limpiarCampos.run());
        btnActualizar.addActionListener(e -> cargarTablaLibros.run());

        JPanel pNorte = new JPanel(new BorderLayout());
        pNorte.add(pForm, BorderLayout.CENTER);
        pNorte.add(pBotones, BorderLayout.SOUTH);

        panel.add(pNorte, BorderLayout.NORTH);
        panel.add(new JScrollPane(tablaLibros), BorderLayout.CENTER);
        return panel;
    }

    private JPanel crearPanelEstudiantes() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        modeloEstudiantes = new DefaultTableModel(new String[]{"ID", "Nombre", "RUT", "Curso", "Correo"}, 0);
        JTable tablaEstudiantes = new JTable(modeloEstudiantes);

        JPanel pForm = new JPanel(new GridLayout(5, 2, 5, 5));
        pForm.setBorder(BorderFactory.createTitledBorder("Gestión de Estudiantes"));

        JTextField txtId = new JTextField(); txtId.setEditable(false);
        JTextField txtNombre = new JTextField();
        JTextField txtRut = new JTextField();
        JTextField txtCurso = new JTextField();
        JTextField txtCorreo = new JTextField();

        pForm.add(new JLabel(" ID (Auto):")); pForm.add(txtId);
        pForm.add(new JLabel(" Nombre:")); pForm.add(txtNombre);
        pForm.add(new JLabel(" RUT:")); pForm.add(txtRut);
        pForm.add(new JLabel(" Curso:")); pForm.add(txtCurso);
        pForm.add(new JLabel(" Correo:")); pForm.add(txtCorreo);

        JPanel pBotones = new JPanel(new FlowLayout());
        JButton btnRegistrar = new JButton("Registrar");
        JButton btnModificar = new JButton("Modificar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnLimpiar = new JButton("Limpiar");
        JButton btnActualizar = new JButton("Actualizar Tabla");

        pBotones.add(btnRegistrar); pBotones.add(btnModificar); pBotones.add(btnEliminar); pBotones.add(btnLimpiar); pBotones.add(btnActualizar);

        cargarTablaEstudiantes = () -> {
            modeloEstudiantes.setRowCount(0);
            for (Estudiante est : new EstudianteDAO().listar()) {
                modeloEstudiantes.addRow(new Object[]{est.getId(), est.getNombre(), est.getRut(), est.getCurso(), est.getCorreo()});
            }
        };
        cargarTablaEstudiantes.run();

        Runnable limpiarCampos = () -> {
            txtId.setText(""); txtNombre.setText(""); txtRut.setText(""); txtCurso.setText(""); txtCorreo.setText("");
            tablaEstudiantes.clearSelection();
        };

        tablaEstudiantes.getSelectionModel().addListSelectionListener(e -> {
            int fila = tablaEstudiantes.getSelectedRow();
            if (fila >= 0) {
                txtId.setText(tablaEstudiantes.getValueAt(fila, 0).toString());
                txtNombre.setText(tablaEstudiantes.getValueAt(fila, 1).toString());
                txtRut.setText(tablaEstudiantes.getValueAt(fila, 2).toString());
                txtCurso.setText(tablaEstudiantes.getValueAt(fila, 3).toString());
                txtCorreo.setText(tablaEstudiantes.getValueAt(fila, 4).toString());
            }
        });

        btnRegistrar.addActionListener(e -> {
            Estudiante est = new Estudiante(0, txtNombre.getText().trim(), txtRut.getText().trim(), txtCurso.getText().trim(), txtCorreo.getText().trim());
            boolean res = new EstudianteDAO().insertar(est);
            JOptionPane.showMessageDialog(this, res ? "Estudiante registrado con éxito." : "Error al registrar.");
            if (res) { cargarTablaEstudiantes.run(); limpiarCampos.run(); }
        });

        btnModificar.addActionListener(e -> {
            try {
                if (txtId.getText().isEmpty()) { JOptionPane.showMessageDialog(this, "Seleccione un estudiante."); return; }
                Estudiante est = new Estudiante(Integer.parseInt(txtId.getText().trim()), txtNombre.getText().trim(), txtRut.getText().trim(), txtCurso.getText().trim(), txtCorreo.getText().trim());
                boolean res = new EstudianteDAO().actualizar(est);
                JOptionPane.showMessageDialog(this, res ? "Estudiante modificado con éxito." : "Error al modificar.");
                if (res) { cargarTablaEstudiantes.run(); limpiarCampos.run(); }
            } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Error en los datos."); }
        });

        btnEliminar.addActionListener(e -> {
            try {
                if (txtId.getText().isEmpty()) { JOptionPane.showMessageDialog(this, "Seleccione un estudiante."); return; }
                int id = Integer.parseInt(txtId.getText().trim());
                if (JOptionPane.showConfirmDialog(this, "¿Desea eliminar este estudiante?", "Confirmar", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                    boolean res = new EstudianteDAO().eliminar(id);
                    JOptionPane.showMessageDialog(this, res ? "Estudiante eliminado." : "Error al eliminar.");
                    if (res) { cargarTablaEstudiantes.run(); limpiarCampos.run(); }
                }
            } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Selección inválida."); }
        });

        btnLimpiar.addActionListener(e -> limpiarCampos.run());
        btnActualizar.addActionListener(e -> cargarTablaEstudiantes.run());

        JPanel pNorte = new JPanel(new BorderLayout());
        pNorte.add(pForm, BorderLayout.CENTER);
        pNorte.add(pBotones, BorderLayout.SOUTH);

        panel.add(pNorte, BorderLayout.NORTH);
        panel.add(new JScrollPane(tablaEstudiantes), BorderLayout.CENTER);
        return panel;
    }

    private JPanel crearPanelReportes() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JTextArea txtResultado = new JTextArea();
        txtResultado.setEditable(false);

        JButton btnTopLibros = new JButton("1. Libros más prestados");
        JButton btnLibrosPrestamo = new JButton("2. Libros en préstamo actual");
        JButton btnHistorialEstudiante = new JButton("3. Historial por estudiante");

        btnTopLibros.addActionListener(e -> txtResultado.setText(new PrestamoDAO().obtenerLibrosMasPrestados()));
        btnLibrosPrestamo.addActionListener(e -> txtResultado.setText(new PrestamoDAO().obtenerLibrosActualmenteEnPrestamo()));

        btnHistorialEstudiante.addActionListener(e -> {
            String input = JOptionPane.showInputDialog(this, "Ingrese el ID del estudiante:");
            if (input != null && !input.trim().isEmpty()) {
                try {
                    int idE = Integer.parseInt(input.trim());
                    txtResultado.setText(new PrestamoDAO().obtenerHistorialPorEstudiante(idE));
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Ingrese un ID numérico válido.");
                }
            }
        });

        JPanel pNorte = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pNorte.add(btnTopLibros);
        pNorte.add(btnLibrosPrestamo);
        pNorte.add(btnHistorialEstudiante);

        panel.add(pNorte, BorderLayout.NORTH);
        panel.add(new JScrollPane(txtResultado), BorderLayout.CENTER);
        return panel;
    }
}
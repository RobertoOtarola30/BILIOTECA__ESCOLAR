package com.biblioteca.modelo;

public class Usuario extends Persona {
    private String rol;
    private String contrasena;

    public Usuario(int id, String nombre, String rut, String correo, String contrasena, String rol) {
        super(id, nombre, rut, correo);
        this.contrasena = contrasena;
        this.rol = rol;
    }

    public String getRol() { return rol; }
    public void setRol(String rol) { this.rol = rol; }

    public String getContrasena() { return contrasena; }
    public void setContrasena(String contrasena) { this.contrasena = contrasena; }

    @Override
    public String obtenerDetalleRol() {
        return "Personal administrativo con rol de: " + rol;
    }
}